package db

import (
	"time"

	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

// Definisikan struct model untuk job_postings
type JobPosting struct {
	ID              uint       `json:"id" gorm:"primaryKey;autoIncrement"`
	NamaPekerjaan   string     `json:"nama_pekerjaan" gorm:"type:varchar(255);not null"`
	Email           string     `json:"email" gorm:"type:varchar(255);not null"`
	HargaPekerjaan  float64    `json:"harga_pekerjaan" gorm:"type:decimal(10,2);not null"`
	Deskripsi       string     `json:"deskripsi" gorm:"type:text;not null"`
	SyaratKetentuan string     `json:"syarat_ketentuan" gorm:"type:text;not null"`
	LingkupKerja    string     `json:"lingkup_kerja" gorm:"type:text;not null"`
	StatusPekerjaan string     `json:"status_pekerjaan" gorm:"type:enum('Tersedia', 'Dalam Proses', 'Selesai');default:'Tersedia'"`
	JenisPekerjaan  string     `json:"jenis_pekerjaan" gorm:"type:enum('Kebersihan', 'Perbaikan Rumah', 'Perbaikan Kendaraan', 'Perbaikan Elektronik', 'Tutor', 'Rumah Tangga', 'Fotografi & Videografi', 'Lainnya');default:'Lainnya'"`
	StatusPekerja   *string    `json:"status_pekerja" gorm:"type:enum('Menunggu', 'Bekerja', 'Selesai');default:null"`
	Time            int        `json:"time" gorm:"type:int(11);not null"`
	TanggalDanWaktu string     `json:"tanggaldanwaktu" gorm:"type:varchar(255);not null"` // Sesuaikan dengan kolom di tabel
	EmailPengambil  *string    `json:"email_pengambil" gorm:"type:varchar(255);default:null"`
	Image1          *string    `json:"image1" gorm:"type:varchar(255);default:null"`
	Image2          *string    `json:"image2" gorm:"type:varchar(255);default:null"`
	Image3          *string    `json:"image3" gorm:"type:varchar(255);default:null"`
	Status          *string    `json:"status" gorm:"type:enum('pending', 'success', 'failed');default:null"`
	CreatedAt       *time.Time `json:"created_at" gorm:"type:timestamp;default:null"`
	UpdatedAt       *time.Time `json:"updated_at" gorm:"type:timestamp;default:null"`
	ApplicantsCount int        `json:"applicants_count" gorm:"type:int(11);default:0"`
	Lokasi          string     `json:"lokasi" gorm:"type:varchar(255);default:null"`
}

// Fungsi untuk menghubungkan ke database MySQL
func ConnectDatabase() (*gorm.DB, error) {
	// Ganti dengan konfigurasi database MySQL kamu
	dsn := "root:@tcp(localhost:3307)/laravel?charset=utf8&parseTime=True&loc=Local"
	db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{})
	if err != nil {
		return nil, err
	}

	// Tanpa AutoMigrate, karena kamu mengelola tabel secara manual
	// db.AutoMigrate(&JobPosting{}) // Hapus atau komentari bagian ini jika tidak ingin migrasi otomatis

	return db, nil
}

// Fungsi untuk menangani pengisian waktu `CreatedAt` dan `UpdatedAt` secara manual
func (job *JobPosting) BeforeCreate(tx *gorm.DB) (err error) {
	// Set CreatedAt dan UpdatedAt saat entri baru dibuat
	if job.CreatedAt == nil {
		now := time.Now()
		job.CreatedAt = &now
	}
	if job.UpdatedAt == nil {
		now := time.Now()
		job.UpdatedAt = &now
	}
	return
}
