package controllers

import (
	"fmt"
	"log"
	"net/http"
	"time"

	db "flutter_api/database" // Mengimpor package db yang telah kamu buat
	"flutter_api/models"      // Mengimpor model JobPosting

	"github.com/gin-gonic/gin"
)

func CreateJob(c *gin.Context) {
	// Menambahkan log untuk melihat apakah request POST diterima oleh server
	log.Println("Received POST request to /jobs")

	var job models.JobPosting
	if err := c.ShouldBind(&job); err != nil {
		log.Printf("Failed to bind form data: %s", err.Error()) // Log jika binding gagal
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Log data yang diterima dari Flutter
	log.Printf("Job data received: %+v", job)

	// Jika tanggal tidak disertakan, set tanggal saat ini
	if job.TanggalDanWaktu.IsZero() {
		job.TanggalDanWaktu = time.Now()
	}

	// Menyimpan gambar ke server
	for i := 1; i <= 3; i++ {
		file, err := c.FormFile(fmt.Sprintf("image%d", i))
		if err == nil {
			filePath := fmt.Sprintf("./uploads/%s", file.Filename)
			if err := c.SaveUploadedFile(file, filePath); err != nil {
				log.Printf("Failed to save file %s: %s", file.Filename, err.Error()) // Log jika gagal menyimpan file
				c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save file"})
				return
			}

			// Menyimpan path file ke struct JobPosting
			switch i {
			case 1:
				job.Image1 = &filePath // Gunakan pointer
			case 2:
				job.Image2 = &filePath // Gunakan pointer
			case 3:
				job.Image3 = &filePath // Gunakan pointer
			}
		}
	}

	// Koneksi ke database menggunakan package db
	dbInstance, err := db.ConnectDatabase() // Menggunakan koneksi dari package db
	if err != nil {
		log.Printf("Database connection failed: %s", err.Error()) // Log jika gagal koneksi database
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Database connection failed"})
		return
	}

	// Simpan data pekerjaan ke database
	if err := dbInstance.Create(&job).Error; err != nil {
		// Log error lebih detail jika terjadi error saat menyimpan data
		log.Printf("Failed to save job. Error: %v", err) // Log error database

		// Cek apakah error terkait constraint atau data yang hilang
		if err.Error() == "record not found" {
			log.Println("Database error: Record not found")
		} else if err.Error() == "duplicate entry" {
			log.Println("Database error: Duplicate entry detected")
		}

		// Cek juga log data yang dikirimkan ke database
		log.Printf("Data received for creation: %+v", job)

		// Response error
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save job"})
		return
	}

	// Log sukses jika data berhasil disimpan
	log.Printf("Job created successfully: %+v", job) // Log sukses dengan data pekerjaan

	// Response sukses
	c.JSON(http.StatusOK, gin.H{"message": "Job created successfully", "data": job})
}

func GetJobs(c *gin.Context) {
	var jobs []models.JobPosting // Gunakan model JobPosting dari models

	// Koneksi ke database menggunakan package db
	dbInstance, err := db.ConnectDatabase() // Menggunakan koneksi dari package db
	if err != nil {
		log.Printf("Database connection failed: %s", err.Error())
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Database connection failed"})
		return
	}

	// Ambil data pekerjaan dari database
	if err := dbInstance.Find(&jobs).Error; err != nil {
		log.Printf("Failed to get jobs: %s", err.Error())
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to retrieve jobs"})
		return
	}

	// Kembalikan hasil ke client
	c.JSON(http.StatusOK, gin.H{"data": jobs})
}

// Fungsi untuk mengambil pekerjaan berdasarkan ID
func GetJobByID(c *gin.Context) {
	id := c.Param("id")       // Ambil parameter ID dari URL
	var job models.JobPosting // Gunakan model JobPosting dari models

	// Koneksi ke database menggunakan package db
	dbInstance, err := db.ConnectDatabase() // Menggunakan koneksi dari package db
	if err != nil {
		log.Printf("Database connection failed: %s", err.Error())
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Database connection failed"})
		return
	}

	// Cari pekerjaan berdasarkan ID
	if err := dbInstance.First(&job, id).Error; err != nil {
		log.Printf("Failed to get job: %s", err.Error())
		c.JSON(http.StatusNotFound, gin.H{"error": "Job not found"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"data": job})
}
