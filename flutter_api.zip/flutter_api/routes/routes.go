package routes

import (
	"flutter_api/controllers"

	"github.com/gin-gonic/gin"
)

func AuthRoutes(r *gin.Engine) {
	r.POST("/register", controllers.Register)
	r.POST("/login", controllers.Login)
}

func JobRoutes(r *gin.Engine) {
	// Route untuk pekerjaan (job)
	r.POST("/jobs", controllers.CreateJob)     // Menambahkan pekerjaan
	r.GET("/jobs", controllers.GetJobs)        // Mengambil semua pekerjaan
	r.GET("/jobs/:id", controllers.GetJobByID) // Mengambil pekerjaan berdasarkan ID
}

func SetupRouter() *gin.Engine {
	r := gin.Default()

	// Menambahkan middleware CORS
	r.Use(func(c *gin.Context) {
		c.Header("Access-Control-Allow-Origin", "*") // Izinkan akses dari semua origin
		c.Header("Access-Control-Allow-Methods", "POST, GET, OPTIONS, PUT, DELETE")
		c.Header("Access-Control-Allow-Headers", "Origin, Content-Type, X-Auth-Token")
		c.Next()
	})

	// Daftarkan route untuk autentikasi
	AuthRoutes(r)

	// Daftarkan route untuk pekerjaan
	JobRoutes(r)

	return r
}
