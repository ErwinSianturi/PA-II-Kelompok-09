package main

import (
	db "flutter_api/database"
	"flutter_api/routes" // Pastikan path yang benar untuk routing
	"log"
)

// Menghubungkan ke database dan melakukan migrasi
func main() {
	// Menghubungkan ke database dan melakukan migrasi
	_, err := db.ConnectDatabase() // Menggunakan koneksi dari package db
	if err != nil {
		log.Fatal("Failed to connect to the database:", err) // Menangani error jika koneksi gagal
	}

	r := routes.SetupRouter() // Memanggil routing API

	// Jalankan server di port 8080
	if err := r.Run(":8080"); err != nil {
		log.Fatal("Failed to run the server:", err) // Menangani error jika server gagal berjalan
	}
}
